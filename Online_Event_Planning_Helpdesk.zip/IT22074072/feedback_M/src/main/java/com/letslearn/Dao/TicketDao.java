package com.letslearn.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.letslearn.Modal.Ticket;

public class TicketDao {
	private Connection con;
	private String query;
    private PreparedStatement pst;
    private ResultSet rs;

	public TicketDao(Connection con) {
		this.con = con;
	}
	
	public int addTicket(Ticket ticket) {
		int result = 0;
  		try {
  			query="INSERT INTO ticket (name,complainType,tel,description,ticketSub)\r\n"
  					+ "VALUES (?,?,?,?,?);";
  			pst = this.con.prepareStatement(query);
            pst.setString(1,  ticket.getName());
            pst.setString(2, ticket.getComplaintype());
            pst.setString(3, ticket.getTel());
            pst.setString(4, ticket.getDescription());
            pst.setString(5, ticket.getTicketSub());
            result=pst.executeUpdate();
  		}catch(Exception e) {
  			e.printStackTrace();
  		}
  		return result;
	}
	//get coupon id name
	public List<Ticket> getAllTickets(){
  		List<Ticket> ticket = new ArrayList<Ticket>();
  		try {
  			query="select * from ticket";
  			pst=this.con.prepareStatement(query);
  			rs=pst.executeQuery();
  			while(rs.next()) {
  				Ticket cpn = new Ticket("","","");
  				cpn.setName(rs.getString("name"));
  				cpn.setComplaintype(rs.getString("complainType"));
  				cpn.setTel(rs.getString("tel"));
  				cpn.setDescription(rs.getString("description"));
  				cpn.setTicketSub(rs.getString("ticketSub"));
  				cpn.setId(rs.getString("id"));
  				ticket.add(cpn);
  				
  			}
  		}catch(Exception e) {
  			e.printStackTrace();
  		}
  		return ticket;
  		
  	}
	
	public int deleteTicket(String id) {
  		int result=0;
  		try {
  			query="DELETE FROM ticket WHERE id=?;";
  			pst = this.con.prepareStatement(query);
            pst.setString(1,id);
      
            result=pst.executeUpdate();
  		}catch(Exception e) {
  			e.printStackTrace();
  		}
  		return result;
  	}
	
	//updating coupons
  	public int updateTicket(Ticket ticket) {
  		System.out.println(ticket.getId());
  		int result=0;
  		try {
  			query="UPDATE ticket SET name = ?, complainType= ? , tel=?,description=?,ticketSub=? WHERE id = ?;";
  			pst = this.con.prepareStatement(query);
  			 pst.setString(1,  ticket.getName());
             pst.setString(2, ticket.getComplaintype());
             pst.setString(3, ticket.getTel());
             pst.setString(4, ticket.getDescription());
             pst.setString(5, ticket.getTicketSub());
             pst.setString(6, ticket.getId());
            result=pst.executeUpdate();
  		}catch(Exception e) {
  			e.printStackTrace();
  		}
  		return result;
  	}

}
