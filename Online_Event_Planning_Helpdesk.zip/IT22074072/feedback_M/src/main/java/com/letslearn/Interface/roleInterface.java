package com.letslearn.Interface;

public interface roleInterface {
	public void displayRole();
}
