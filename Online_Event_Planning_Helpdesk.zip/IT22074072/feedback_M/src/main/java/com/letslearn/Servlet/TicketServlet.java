package com.letslearn.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.letslearn.DBcon.DbCon;
import com.letslearn.Dao.TicketDao;
import com.letslearn.Modal.Ticket;

/**
 * Servlet implementation class TicketServlet
 */
@WebServlet("/TicketServlet")
public class TicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private int result = 0;
	RequestDispatcher dis = null;
	String action = null;
	String fname = null;
	String tel = null;
	String description = null;
	String ticketType = null;
	String ticketSub = null;
	String id = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		action = request.getParameter("action");
		if(action.equals("delete")){
			fname = request.getParameter("fname");
			tel = request.getParameter("tel");
			description = request.getParameter("description");
			ticketType = request.getParameter("ticketType");
			ticketSub = request.getParameter("ticketSub");
			id = request.getParameter("ticketId");
			System.out.println(id);
			try {
				TicketDao ticketDao = new TicketDao(DbCon.getConnection());
				result = ticketDao.deleteTicket(id);
				if (result != 0) {
					response.sendRedirect("ticketManagement.jsp");
					
				} else {
					// Send a JavaScript alert for an error
					out.write("<script>alert('An error . Please try again.');</script>");
				}
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		action = request.getParameter("action");
		
		fname = request.getParameter("fname");
		tel = request.getParameter("tel");
		description = request.getParameter("description");
		ticketType = request.getParameter("ticketType");
		ticketSub = request.getParameter("ticketSub");
		id = request.getParameter("ticketId");
		
		System.out.println(id);

		if(action.equals("addTicket")) {
			try {
				Ticket ticket = new Ticket(fname, "", "", ticketType, description, ticketSub,id,tel);
				TicketDao ticketDao = new TicketDao(DbCon.getConnection());
				result = ticketDao.addTicket(ticket);
				if (result != 0) {
					response.sendRedirect("ticketManagement.jsp");
				} else {
					// Send a JavaScript alert for an error
					out.write("<script>alert('An error occurred. Please try again.');</script>");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if(action.equals("update")){
			try {
				Ticket ticket = new Ticket(fname, "", "", ticketType, description, ticketSub,id,tel);
				TicketDao ticketDao = new TicketDao(DbCon.getConnection());
				result = ticketDao.updateTicket(ticket);
				if (result != 0) {
					response.sendRedirect("ticketManagement.jsp");
				} else {
					// Send a JavaScript alert for an error
					out.write("<script>alert('An error  Please try again.');</script>");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
