package com.letslearn.Modal;

public class Ticket extends User {
	
	private String complaintype;
	private String description;
	private String ticketSub;
	private String id;
	private String tel;
	
	public Ticket(String name, String email, String nic) {
		super(name, email, nic);
		// TODO Auto-generated constructor stub
	}

	
	
	public Ticket(String name, String email, String nic, String complaintype, String description, String ticketSub,
			String id, String tel) {
		super(name, email, nic);
		this.complaintype = complaintype;
		this.description = description;
		this.ticketSub = ticketSub;
		this.id = id;
		this.tel = tel;
	}



	public String getComplaintype() {
		return complaintype;
	}

	public void setComplaintype(String complaintype) {
		this.complaintype = complaintype;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTicketSub() {
		return ticketSub;
	}

	public void setTicketSub(String ticketSub) {
		this.ticketSub = ticketSub;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}
	
	
}
