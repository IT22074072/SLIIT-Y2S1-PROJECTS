package com.letslearn.Interface;

public class RoleImplementation implements roleInterface {
    @Override
    public void displayRole() {
        System.out.println("\nUser Role: Ticket Management");
    }
}